
import React, { useRef } from 'react';
import OnImagesLoaded from 'react-on-images-loaded';
import { utilAnimate } from '../util/utilAnimate';


export default function LoadContainer ( { children } ) {

    const containerRef = useRef(null);
    const onImagesLoaded = () => {
        utilAnimate.fadeIn(containerRef.current);
    }

    return (
        <>
            <div className='shared--loading'></div>
            <div className='shared--load-container' ref={ containerRef }>
                <OnImagesLoaded onLoaded={ onImagesLoaded } >
                    { children }
                </OnImagesLoaded>
            </div>
        </>
    );

}