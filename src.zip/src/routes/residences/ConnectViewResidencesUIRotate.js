import React from 'react';
import { connect } from 'react-redux'
import { updateRotation, updateIsAnimating } from './'
import rotateResidences from './rotateResidences';
import ButtonResidencesRotate from './ButtonResidencesRotate';


function ViewResidencesUIRotate ( { currRotation, isAnimating, updateRotation, updateIsAnimating } ) {

  const onRotateSelected = (increment) => {
    if (!isAnimating) {
      updateIsAnimating(true);
      rotateResidences(increment, currRotation, onResidencesRotating, onBuildingRotationComplete);
    }
  }

  const onResidencesRotating = (rotation) => { 
    updateRotation(rotation);
  }

  const onBuildingRotationComplete = () => {
    updateIsAnimating(false);
  }

  return (
    <>
      <ButtonResidencesRotate className='residences--button__rotate-left' imgRef='./img/interface/btn-rotate-left.png' onSelected={ () => onRotateSelected('+=18') } />
      <ButtonResidencesRotate className='residences--button__rotate-right' imgRef='./img/interface/btn-rotate-right.png' onSelected={ () => onRotateSelected('-=18') }  />
    </>
  );

}


const mapStateToProps = (state) => ({
  currRotation: state.residences.currRotation,
  isAnimating: state.residences.isAnimating
})

const mapDispatchToProps = (dispatch) => ({
  updateRotation: (currRotation) => dispatch(updateRotation(currRotation)),
  updateIsAnimating: (isAnimating) => dispatch(updateIsAnimating(isAnimating))
})

export default connect(mapStateToProps, mapDispatchToProps)(ViewResidencesUIRotate)