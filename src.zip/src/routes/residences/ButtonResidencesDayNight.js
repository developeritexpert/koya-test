import React from "react";
const ButtonResidencesDayNight = ({ data, onSelect, selected }) => {
    return (
        <button className={ selected ? "residences--building__btn_Day_Night__active" : "residences--building__btn_Day_Night" } onClick={onSelect} style={{ top: data.top, left: data.left }}>{data.title}</button>
    )
}

export default ButtonResidencesDayNight;