import React, { useRef } from 'react';
import { selectEnlarged } from '../../shared/enlarged';
import { connect } from 'react-redux';
import { utilAnimate } from '../../util/utilAnimate'


function ButtonAerialHotspot ( { data, onSelected, selectEnlarged } ) {
  
  const imgRef = useRef(null);
  
  const onMouseEnter = (event) => {
    onSelected(event.currentTarget.parentNode); //to ensure it appears over the other hotspots
    utilAnimate.fadeIn(imgRef.current);
  }

  const onClick = () => {
    if (data.href !== undefined) {
      selectEnlarged( { srcList: [data.href] } );
    }
  }

  const onMouseLeave = () => {
    utilAnimate.fadeOut(imgRef.current);
  }

  return (
    <div className='features--hotspot' style={ { left: data.left, top: data.top } }>
      <button className='features--hotspot__btn' onClick={ onClick } onMouseEnter={ onMouseEnter } onMouseLeave={ onMouseLeave } ></button>
      <img className='features--hotspot__tmb' src={ data.src } ref={ imgRef } alt={ data.title } />
    </div>
  );

}


const mapStateToProps = (state) => ({});

const mapDispatchToProps = (dispatch) => ({
  selectEnlarged: (data) => dispatch(selectEnlarged(data))
});

export default connect(mapStateToProps, mapDispatchToProps)(ButtonAerialHotspot);