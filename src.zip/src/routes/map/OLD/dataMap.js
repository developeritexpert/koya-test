
export const data = [
    { 
        title: 'Transport',
        options: [
            { title: 'Train', file: 'train' },
            { title: 'Tram', file: 'tram'  },
            { title: 'Bus', file: 'bus'  },
        ]
    },
    { 
        title: 'Amenities',
        options: [
            { title: 'Sports & Recreation', file: 'sports'  },
            { title: 'Shopping', file: 'shopping'  },
            { title: 'Entertainment & Culture', file: 'entertainment'  },
            { title: 'Education', file: 'education'  },
            { title: 'Dining', file: 'dining'  },
        ]
    }
];